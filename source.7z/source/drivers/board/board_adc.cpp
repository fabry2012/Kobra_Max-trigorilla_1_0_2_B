#include "board_adc.h"


void setup_adcs(void)
{

}

void adc_main(void)
{

}

uint16_t adc_read(adc_dev *dev, uint8_t channel)
{

}

