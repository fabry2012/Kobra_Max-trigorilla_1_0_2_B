#ifndef __BSP_OTS_H__
#define __BSP_OTS_H__




void bsp_ots_init(void);
void test_ots(void);




#endif

